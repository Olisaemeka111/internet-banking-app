exports.handler = async (event, context) => {
  console.log('Security scan completed');
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Add notification logic here (e.g., SNS, Slack, etc.)
  
  return {
    statusCode: 200,
    body: JSON.stringify('Security notification sent'),
  };
};
